 # include <stdio.h> //elahe babaei
                     //4023007
int main ()
{
    int n , i ,k,j,stop;
    j=0;

    printf ("\tplease enter number \n");
    scanf ("%d",&n);
    
    char ebarat [n+1];

    printf ("\tplease enter  expression\n");
    scanf ("%s",&ebarat );
   
    while (1)
    {
        stop=0;
        for (i=0;i<n;i++)
        {  
           if (ebarat[i]==ebarat[i+1])
            {
              j=i;// shomrh khone ke barbar shodeh
               break;
            }          
        }
        for (;j<n;j++)
            ebarat[j]=ebarat[j+2];
       printf("%s\n",ebarat);
       for (k=0;k<n;k++)
            if (ebarat[k]==ebarat[k+1])
              ++stop;
        if(stop==0)
          break;
    }
}
    